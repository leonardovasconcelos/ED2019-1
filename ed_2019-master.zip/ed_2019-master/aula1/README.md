# Data: 14/03/2019

* Apresentação do curso: objetivos, tópicos a serem apresentados, critério de avaliação a ser empregado e literatura utilizada;
* Introdução a linguagem C: tipos e variáveis;
* Operadores: aritméticos, de incremento, de decremento, relacionais e lógicos;
* Precedência de operadores;
* Operadores: binários, ternário e sizeof(tipo);
* Entrada e saída básicas (scanf e printf);
* Decisões com if;
* Repetições com for; e