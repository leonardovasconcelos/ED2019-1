# Data: 11/04/2019

* Outras operações básicas que possuem versões iterativa e recursiva:
** (a) impressão da lista,
** (b) liberação da lista,
** (c) remoção de um elemento da lista,
** (d) busca de um elemento e
** (e) ordenação de lista, alterando o conteúdo do campo info;
* Motivação para o uso de listas circulares;
* Definição de listas circulares;
* Operações básicas:
** (a) inicialização,
** (b) busca de um elemento,
** (c) impressão da lista,
** (d) liberação da lista,
** (e) inserção mais barata, em termos de complexidade, de um elemento na lista,
** (f) inserção mais cara, em termos de complexidade, de um elemento na lista e
** (g) retirada de uma ocorrência de um elemento nesta lista;
* Motivação para o uso de listas duplamente encadeadas;
* Definição de listas duplamente encadeadas;
* Operações básicas:
** (a) inicialização,
** (b) busca de um elemento,
** (c) impressão da lista,
** (d) liberação da lista e
** (e) inserção de um elemento no início da lista; e