# Data: 04/04/2019

* Mais sobre funções recursivas: caso base e caso recursivo;
* Declaração de matrizes;
* Alocação dinâmica de matrizes;
* Passagem de matriz como parâmetro de entrada de funções;
* Exemplo de aplicação: função que verifica a simetria da matriz recebida como parâmetro de entrada, e retorna ou a matriz transposta, ou a matriz simétrica otimizada em relação à memória;
* Tipo estrutura;
* Variáveis do tipo estrutura;
* Ponteiros para o tipo estrutura;
* Motivação para o uso de listas;
* Definição de listas;
* Operações básicas que só possuem uma versão iterativa: (a) inicialização e (b) inserção de um elemento no início da lista;
* Operações básicas que possuem versões iterativa e recursiva: (a) inserção de um elemento no fim de uma lista e (b) inserção de um elemento na lista ordenada; e