# Data: 28/03/2019

* Implementação das versões iterativa e recursiva do algoritmo de ordenação selection sort;
* Ordenação de vetor usando o algoritmo de ordenação quicksort, e apresentação da função qsort presente em stdlib.h;
* Alocação dinâmica de vetores usando malloc, realloc e free da biblioteca stdlib.h;
* Exemplo de aplicação: ordenação dos dados de um vetor, mantendo a ordem do vetor original;
* Cadeia de caracteres;
* Leitura e escrita de cadeia de caracteres;
* Apresentação de funções da bilioteca string.h: implementação de versões iterativa e recursiva de strcpy e strcmp; e