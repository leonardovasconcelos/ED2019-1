# Adicionando a biblioteca ao seu programa

1. Inclua no seu arquivo **main.c** o seguinte cabeçalho
   
   ```
    #include "<caminho_para>/utils/utils.c"
   ```
   onde <caminho_para> é o caminho relativo ao diretório de onde você está compilando seu programa.

2. Adicionar a chamada pra a função que deseja utilizar no seu código:
   ```
    *
    *
    *
    imprime(vet,n);
    *
    *
    *
    ```
