void imprime(int *vet, int n);
void imprime(int *vet, int n){
    int i = 0;
    for(i = 0; i <n; i++){
        printf("%d ",vet[i]);
    }
    printf("\n");
}