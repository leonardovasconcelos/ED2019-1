#include <stdio.h>

int main(void) {
  int a, b, x;
  scanf("%d",&a);
  scanf("%d",&b);

  x = a + b;
  printf("X = %d\n",x);
}