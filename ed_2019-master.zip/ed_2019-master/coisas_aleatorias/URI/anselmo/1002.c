#include <stdio.h>

int main(void) {
  double r;

  scanf("%lf",&r);

  printf("A=%.4f\n",3.14159*r*r);
}