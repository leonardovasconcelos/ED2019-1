# Data: 21/03/2019

* Repetições com while, for e do-while;
* break e continue;
* Seleção com switch-case-default;
* Funções e pilha de execução; e
* Ponteiros;
* Declaração de vetores;
* Passagem de vetor como parâmetro de entrada de funções;
* Exemplo de aplicação: versão iterativa dos algoritmos de ordenação bubble sort e selection sort;